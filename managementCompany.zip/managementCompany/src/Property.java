 
public class Property {
private String city;
private String owner;
private String propertyName;
private double rentAmount;
private Plot plot;
public Property() {
	this.city = "";
	this.owner = "";
	this.propertyName = "";
	this.rentAmount = 0;
	this.plot = new Plot();
	
}
public Property(Property p){
	this.city = p.getCity();
	this.owner = p.getOwner();
	this.rentAmount = p.getRentAmount();
	this.propertyName = p.getPropertyName();
	this.plot = p.getPlot();
}
public Property( String propertyName, String city, double rentAmount, String owner){
	this.propertyName = propertyName;
	this.city = city;
	this.rentAmount = rentAmount;
	this.owner = owner;
	this.plot = new Plot();
}
public Property(String propertyName, String city, double rentAmount, String owner,int x, int y, int width, int depth ) {
	this.propertyName = propertyName;
	this.city = city;
	this.owner = owner;
	this.rentAmount = rentAmount;
	this.plot= new Plot(x,y,width,depth);
}



public String getPropertyName() {
	return this.propertyName;
}
public void setPropertyName(String getPropertyName) {
	this.propertyName = getPropertyName;
	}


public String getCity() {
	return this.city;
} 
public void setCity(String getCity) {
	this.city = getCity;
}


public double getRentAmount() {
	return this.rentAmount;
}
public void setRentAmount(double getRentAmount) {
	this.rentAmount = getRentAmount;
}


public String getOwner() {
	return this.owner;
} 
public void setOwner(String getOwner) {
	this.city = getOwner;
}


public Plot getPlot() {
	return this.plot;
}
public void setPlot(Plot getPlot) {
	this.plot = getPlot;
}


@Override 
public String toString() {
	return "property Name: " + propertyName + "\nLocated in city: " + city + "\nBelonging to: "+ owner + "\nRetn Amount: "+ rentAmount;
}

}
