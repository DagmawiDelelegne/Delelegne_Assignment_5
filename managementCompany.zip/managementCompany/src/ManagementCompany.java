
/*
 * CMSC 203
 * Assignment 4: a property management company
 * Instructor: Ahmed Tarek
 * Due: 3/28/23
 * I pledge that I have completed the programming assignment independently.
   I have not copied the code from a student or any source.
   I have not given my code to any student.
   Print your Name here: Dagmawi Delelegne
 * 
 * */

import javafx.scene.layout.Region;

public class ManagementCompany {
	private int MAX_PROPERTY = 5;
	private int MGMT_WDTH = 10;
	private int MGMT_DEPTH = 10;
	private double mgmFeePer;
	private String name;
	private Property [] properties = new Property[MAX_PROPERTY];
	private String taxID;
	private Plot mgmplot;
	
	
	public ManagementCompany(){
		this.name = "";
		this.taxID= "";
		//check the spelling of plot
		this.mgmplot = new Plot(0,0,MGMT_WDTH,MGMT_DEPTH);
		this.properties = new Property[MAX_PROPERTY];
		
	}
	public ManagementCompany(String name, String taxID, double mgmFee){
		this.name = name;
		this.taxID = taxID;
		this.mgmFeePer = mgmFee;
		this.mgmplot = new Plot(0,0,MGMT_WDTH,MGMT_DEPTH);
		this.properties = new Property[MAX_PROPERTY];
	
	}
	
	public ManagementCompany(String name, String taxID, double mgmFee, int x,int y, int width, int depth){
		this.name = name;
		this.taxID = taxID;
		this.mgmFeePer = mgmFee;
		this.mgmplot = new Plot(x,y,width,depth);
	}
	
public ManagementCompany(ManagementCompany otherCompany) {
	this.name = otherCompany.name;
	this.taxID = otherCompany.taxID;
	this.mgmFeePer = otherCompany.mgmFeePer;
	this.mgmplot = new Plot(otherCompany.mgmplot);
	}


public int getMAX_PROPERTY() {
	return MAX_PROPERTY;
}

public int addProperty(Property property) {
    
	
	if (property == null) {
        return -2;
    }
    Plot propertyPlot = property.getPlot();
    if (!mgmplot.encompasses(propertyPlot)) {
        return -3;
    }
    for (int i = 0; i < properties.length; i++) {
        if (properties[i] != null && properties[i].getPlot().overlaps(propertyPlot)) {
            return -4;
        }
    }
    for (int i = 0; i < properties.length; i++) {
        if (properties[i] == null) {
            properties[i] = property;
            return i;
        }
    }
    return -1;
    	
    
}

public int addProperty(String name, String city, double rent, String owner) {
    Property property = new Property(name, city, rent, owner);
    Plot defaultPlot = new Plot(0, 0, 10, 10);
    int index = -1;
    
    for (int i = 0; i < MAX_PROPERTY; i++) {
        if (properties[i] == null) {
            index = i;
            break;
        }
    }
    
    if (index == -1) {
        return -1;
    }
    
    if (property == null) {
        return -2;
    }
    
    if (!this.mgmplot.encompasses(defaultPlot)) {
        return -3;
    }
    
    for (int i = 0; i < MAX_PROPERTY; i++) {
        if (properties[i] != null && properties[i].getPlot().overlaps(defaultPlot)) {
            return -4;
        }
    }
    
    property.setPlot(defaultPlot);
    properties[index] = property;
    return index;
}

public int addProperty(String name, String city, double rent, String owner, int x, int y, int width, int depth) {
	Property property = new Property(name, city, rent, owner, x, y, width, depth);
	int counter = 0;
	for(int i = 0; i < MAX_PROPERTY; i++) {
		if(properties[i] != null) {
			++counter;
		}
		else{
			break;
		};
	}
	if(counter == MAX_PROPERTY) {
		return -1;
	}
	if(property == null) {
		return -2;
	}
	if(!this.mgmplot.encompasses(property.getPlot())) {
		return -3;
	}
	for(int i = 0; i < MAX_PROPERTY; i++) {
		if(properties[i].getPlot().overlaps(property.getPlot())) {
			return -4;
		}		
	}
	properties[counter] = property;
	return counter;
}

public double totalRent() {
	    double total = 0.0;
	    for (int i =0; i< this.properties.length; i++) {
	    	if (this.properties[i] == null) { continue; }
	        total += this.properties[i].getRentAmount();
	    }
	    return total;
}


public double maxRentProp() {
	 double hRent = 0,cRent = 0;
	for(int i = 0; i < MAX_PROPERTY; i++) {
		if(this.properties[i] == null) {continue;}
		cRent = properties[i].getRentAmount();
		if(cRent > hRent) {
			hRent = cRent;
		}
	}
	return hRent;
	
}
public int maxRentPropIndex() {
	int index = 0;
	double hRent = 0,cRent = 0;
	for(int i = 0; i < MAX_PROPERTY; i++) {
		cRent = properties[i].getRentAmount();
		if(cRent > hRent) {
			index = i;
			hRent = cRent;
		}
		else;
	}
	return index;
	}
private String displayPropertyAtIndex(int i) {
	
		return properties[i].toString();

}
public String toString() {
	StringBuilder sb = new StringBuilder();
    sb.append("List of the properties for ").append(name).append(", taxID: ").append(taxID).append("\n");
    sb.append("______________________________________________________\n");
    for (int i = 0; i < MAX_PROPERTY; i++) {
        if (properties[i] != null) {
            sb.append(properties[i].toString()).append("\n");
        }
    }
    sb.append("______________________\n");
    return sb.toString();
}
public Plot getPlot() {
	// TODO Auto-generated method stub
	return this.mgmplot;
}
public String getName() {
	// TODO Auto-generated method stub
	return this.name;
}
}
	


