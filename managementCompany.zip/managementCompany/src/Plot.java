
public class Plot{
	private int x = 0;
	private int y = 0;
	private int width = 0;
	private int depth = 0;
	Plot(){
		this.width = 1;
		this.depth = 1;
	}
	
	Plot(Plot p){
		this(p.x,p.y,p.width,p.depth);
	}
	
	Plot(int x, int y, int width, int depth){
		this.x = x;
		this.y = y;
		this.width = width;
		this.depth = depth;
	}
	public boolean overlaps(Plot plot) {
		
		int existingX = this.getX();
		int existingY = this.getY();
		int existingWidth = this.getWidth();
		int existingDepth = this.getDepth();
		
		int newX = plot.getX();
		int newY = plot.getY();
		int newWidth = plot.getWidth();
		int newDepth = plot.getDepth();
		
			
		 boolean xOverlap = (existingX < newX + newWidth) && (newX < existingX + existingWidth);
		 boolean yOverlap = (existingY < newY + newDepth) && (newY < existingY + existingDepth);
		 
		 return xOverlap && yOverlap;
	}


	public boolean encompasses(Plot plot) {
		
		boolean encompassesx = (plot.x >= this.x) && (this.x+this.width) >= (plot.x+plot.width);
		boolean encompassesy = (plot.y >= this.y) && (this.y +this.depth) >= (plot.y+plot.depth);
		if(encompassesx && encompassesy) {
			return true;
		}
		else return false;
		
	}
	
	
	public int getX(){
		return this.x;
	}
	public void setX(int x) {
		this.x = x;
	}
	
	
	public int getY() {
		return this.y;
	}
	public void setY(int y) {
		this.y = y;
	}
	
	
	public void setWidth(int width) {
		this.width = width;
	}
	public int getWidth() {
		return this.width;
	}
	
	
	public int getDepth() {
		return this.depth;
	}
	public void setDepth(int depth) {
		this.depth = depth;
	} 
	
	@Override
	public String toString() {
		return "Upper left: (" + this.x +"," + this.y + "); Width: " + this.width + " Depth: " + this.depth;
	}
}
